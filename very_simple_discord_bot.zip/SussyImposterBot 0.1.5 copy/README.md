Sussy Imposter bot by Wistful.

A bot that uses openAi chat bot with commands.

*NOTES*

- In order to host this bot a ffmpeg executable file is needed and should be placed in cogs folder and named 'ffmpeg-1'

Built with the help of the template by:

"""
Copyright © Krypton 2019-2023 - https://github.com/kkrypt0nn (https://krypton.ninja)
Description:
🐍 A simple template to start to code your own and personalized discord bot in Python programming language.

Version: 5.5.0
"""